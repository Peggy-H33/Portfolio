# Career Studio · PM 实习求职助手

一个简洁优雅的简历优化与面试复盘工具，莫兰迪配色，专为互联网产品经理实习求职打造。

## ✨ 功能

- **📎 主简历管理** — 上传 PDF / DOCX / TXT，系统自动解析并长期保存
- **✦ 简历匹配分析** — AI 对比简历与 JD，给出匹配度评分（X/10）+ 逐条修改建议
- **✎ 面试记录** — 保存每次面试的问答和反馈
- **⊹ AI 面试准备** — 结合你的历史面试经验，生成针对性备考计划
- **◷ 历史管理** — 标签分类、筛选、查看完整 AI 分析记录
- **🔐 用户认证** — 邮箱 + Google + GitHub 登录，数据隔离

## 🎨 设计

- **配色**：莫兰迪色系（dusty rose · sage green · warm linen · slate · clay）
- **字体**：Cormorant Garamond（标题）+ DM Sans（正文）
- **风格**：简洁优雅，最小化视觉噪音

## 🏗️ 技术栈

| 层 | 技术 |
|---|---|
| 前端 | Next.js 14 (Pages Router) · React 18 |
| 认证 & 数据库 | Supabase (Auth + Postgres with RLS) |
| AI | Anthropic Claude API |
| 文件解析 | pdf-parse · mammoth |
| 部署 | Vercel |

---

## 🚀 部署指南

### 第一步：创建 Supabase 项目

1. 访问 [supabase.com](https://supabase.com) 注册并创建新项目
2. 进入 **SQL Editor**，粘贴 `supabase_schema.sql` 全部内容并执行
3. 进入 **Authentication → Providers**：
   - **Email**：默认开启
   - **Google**：启用并填入 OAuth Client ID / Secret（[教程](https://supabase.com/docs/guides/auth/social-login/auth-google)）
   - **GitHub**：启用并填入 OAuth App credentials（[教程](https://supabase.com/docs/guides/auth/social-login/auth-github)）
4. 进入 **Settings → API**，记下：
   - `Project URL`
   - `anon public` key

### 第二步：获取 Anthropic API Key

1. 访问 [console.anthropic.com](https://console.anthropic.com)
2. 创建 API key

### 第三步：部署到 Vercel

1. 把代码推送到 GitHub
2. 访问 [vercel.com](https://vercel.com) 导入仓库
3. **Environment Variables** 添加：
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJxxxxxxxx...
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxx...
   ```
4. 点击 **Deploy**
5. 部署完成后，回到 Supabase **Authentication → URL Configuration**，把 Vercel 的 URL 加入 **Site URL** 和 **Redirect URLs**（例如 `https://your-app.vercel.app/**`）

---

## 🧑‍💻 本地开发

```bash
# 安装依赖
npm install

# 复制环境变量
cp .env.local.example .env.local
# 编辑 .env.local 填入你的 keys

# 启动开发服务器
npm run dev
```

访问 http://localhost:3000

---

## 📁 项目结构

```
career-studio/
├── pages/
│   ├── index.js           仪表盘
│   ├── login.js           登录 / 注册
│   ├── resume.js          主简历管理
│   ├── analyze.js         简历匹配分析
│   ├── log.js             记录面试
│   ├── prep.js            面试准备
│   ├── history.js         历史记录
│   ├── _app.js            Supabase session provider
│   └── api/
│       ├── analyze.js           简历 vs JD 分析
│       ├── prep.js              面试备考 AI
│       ├── parse-file.js        PDF/DOCX 解析
│       ├── resume.js            主简历 CRUD
│       └── applications/
│           ├── save.js
│           ├── list.js
│           └── delete.js
├── components/
│   └── Layout.js          带导航与用户菜单
├── lib/
│   ├── supabase.js        客户端
│   └── auth.js            服务端认证中间件
├── styles/
│   └── globals.css        莫兰迪主题
├── supabase_schema.sql    数据库 schema
├── vercel.json            部署配置
└── .env.local.example     环境变量模板
```

---

## 🔒 数据安全

- 所有数据通过 Supabase **Row Level Security (RLS)** 隔离
- API 路由都经过服务端认证中间件 `requireUser()` 校验
- 只有登录用户自己能访问、修改、删除自己的数据

---

## 📝 数据库 Schema

```sql
-- 两张表
applications (投递记录) — user_id, company, role, round, resume_text, jd_text,
                          qa_text, analyze_result, prep_result, match_score
resumes (主简历)       — user_id, content, file_name, title
```

详见 `supabase_schema.sql`。

---

## 🌱 后续扩展建议

- 简历版本对比（每次修改后保存快照）
- 面试题库（把高频题标签化、搜索）
- 邮件提醒（投递后 1 周自动提醒记录进度）
- 多主简历支持（不同岗位配不同版本）

---

Made with ♡ in Morandi tones.
