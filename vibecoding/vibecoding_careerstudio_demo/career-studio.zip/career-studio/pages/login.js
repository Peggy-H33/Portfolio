import { useState, useEffect } from 'react'
import { useRouter } from 'next/router'
import { useSupabaseClient, useUser } from '@supabase/auth-helpers-react'

export default function LoginPage() {
  const supabase = useSupabaseClient()
  const user = useUser()
  const router = useRouter()

  const [mode,     setMode]     = useState('signin') // 'signin' | 'signup'
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [loading,  setLoading]  = useState(false)
  const [msg,      setMsg]      = useState('')
  const [err,      setErr]      = useState('')

  useEffect(() => { if (user) router.push('/') }, [user, router])

  async function handleEmail(e) {
    e.preventDefault()
    setLoading(true); setErr(''); setMsg('')
    try {
      if (mode === 'signup') {
        const { error } = await supabase.auth.signUp({ email, password })
        if (error) throw error
        setMsg('✓ 注册成功！请查收邮件完成验证，然后返回登录。')
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        router.push('/')
      }
    } catch (e) {
      setErr(e.message || '操作失败')
    }
    setLoading(false)
  }

  async function oauth(provider) {
    setLoading(true); setErr('')
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider,
        options: { redirectTo: `${window.location.origin}/` }
      })
      if (error) throw error
    } catch (e) {
      setErr(e.message); setLoading(false)
    }
  }

  return (
    <div className="auth-wrapper">
      <div className="auth-panel fade-in">
        <div className="auth-brand">
          <div className="auth-title">Career Studio</div>
          <div className="auth-sub">PM 实习求职 · 简历优化 · 面试复盘</div>
        </div>

        <div className="auth-tabs">
          <button className={mode === 'signin' ? 'active' : ''} onClick={() => { setMode('signin'); setErr(''); setMsg('') }}>登录</button>
          <button className={mode === 'signup' ? 'active' : ''} onClick={() => { setMode('signup'); setErr(''); setMsg('') }}>注册</button>
        </div>

        <form onSubmit={handleEmail}>
          <div className="form-group" style={{ marginBottom: 12 }}>
            <label className="form-label">邮箱</label>
            <input type="email" required value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com"/>
          </div>
          <div className="form-group" style={{ marginBottom: 18 }}>
            <label className="form-label">密码</label>
            <input type="password" required minLength={6} value={password} onChange={e => setPassword(e.target.value)} placeholder="至少 6 位"/>
          </div>

          {err && <div className="auth-err">{err}</div>}
          {msg && <div className="auth-msg">{msg}</div>}

          <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center' }} disabled={loading}>
            {loading ? '处理中…' : (mode === 'signin' ? '登录' : '创建账号')}
          </button>
        </form>

        <div className="auth-divider"><span>或使用第三方登录</span></div>

        <div className="auth-oauth">
          <button className="btn btn-ghost" onClick={() => oauth('google')} disabled={loading}>
            <span style={{ fontSize: 15 }}>G</span> Google
          </button>
          <button className="btn btn-ghost" onClick={() => oauth('github')} disabled={loading}>
            <span style={{ fontSize: 15 }}>◆</span> GitHub
          </button>
        </div>

        <div className="auth-note">
          登录即表示你同意我们保存你的简历、岗位描述和面试记录以提供 AI 分析服务
        </div>
      </div>

      <style jsx>{`
        .auth-wrapper {
          min-height: 100vh;
          display: flex; align-items: center; justify-content: center;
          padding: 40px 20px;
          background: radial-gradient(circle at 30% 20%, rgba(201,169,154,0.18), transparent 60%),
                      radial-gradient(circle at 70% 80%, rgba(143,168,140,0.15), transparent 60%),
                      var(--cream);
        }
        .auth-panel {
          width: 100%; max-width: 420px;
          background: var(--white);
          border: 1px solid var(--border);
          border-radius: 14px;
          padding: 44px 40px;
          box-shadow: 0 8px 32px rgba(58,53,48,0.08);
        }
        .auth-brand { text-align: center; margin-bottom: 32px; }
        .auth-title {
          font-family: 'Cormorant Garamond', serif;
          font-size: 30px; font-weight: 500;
          color: var(--rose-dark);
          letter-spacing: 0.02em;
        }
        .auth-sub {
          font-size: 11.5px;
          color: var(--ink-lt);
          letter-spacing: 0.08em;
          margin-top: 4px;
        }
        .auth-tabs {
          display: flex; gap: 2px;
          background: var(--cream);
          border-radius: 8px; padding: 4px;
          margin-bottom: 24px;
        }
        .auth-tabs button {
          flex: 1; border: none; background: transparent;
          padding: 9px; border-radius: 6px;
          font-family: 'DM Sans', sans-serif; font-size: 13px; font-weight: 400;
          color: var(--ink-lt); cursor: pointer;
          transition: all 0.15s;
        }
        .auth-tabs button.active {
          background: var(--white); color: var(--rose-dark);
          font-weight: 500;
          box-shadow: 0 1px 3px rgba(0,0,0,0.06);
        }
        .auth-err {
          background: rgba(184,122,122,0.1); color: #9a5555;
          font-size: 12px; padding: 9px 12px; border-radius: 6px;
          margin-bottom: 14px;
        }
        .auth-msg {
          background: rgba(143,168,140,0.12); color: var(--sage-dark);
          font-size: 12px; padding: 9px 12px; border-radius: 6px;
          margin-bottom: 14px;
        }
        .auth-divider {
          display: flex; align-items: center;
          margin: 24px 0 18px;
          color: var(--mist); font-size: 11px;
          letter-spacing: 0.06em;
        }
        .auth-divider::before, .auth-divider::after {
          content: ''; flex: 1; height: 1px; background: var(--border);
        }
        .auth-divider span { padding: 0 14px; }
        .auth-oauth {
          display: grid; grid-template-columns: 1fr 1fr; gap: 10px;
        }
        .auth-oauth button { justify-content: center; }
        .auth-note {
          font-size: 10.5px; color: var(--mist);
          text-align: center; margin-top: 24px;
          line-height: 1.7;
        }
      `}</style>
    </div>
  )
}
