import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useUser } from '@supabase/auth-helpers-react'
import Layout from '../components/Layout'

export default function Home() {
  const user = useUser()
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [hasResume, setHasResume] = useState(false)

  useEffect(() => {
    if (!user) return
    Promise.all([
      fetch('/api/applications/list').then(r => r.json()),
      fetch('/api/resume').then(r => r.json())
    ]).then(([apps, resume]) => {
      setRecords(apps.data || [])
      setHasResume(!!resume.data)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [user])

  const companies   = [...new Set(records.map(r => r.company))].length
  const withQA      = records.filter(r => r.qa_text).length
  const avgScore    = records.filter(r => r.match_score).length
    ? (records.filter(r => r.match_score).reduce((a, r) => a + r.match_score, 0) / records.filter(r => r.match_score).length).toFixed(1)
    : '—'

  return (
    <Layout recordCount={records.length}>
      <div className="page-title">Career Studio</div>
      <p className="page-sub">PM 实习求职 · 简历优化 · 面试复盘</p>

      <div className="stats-row">
        <div className="stat-box">
          <div className="stat-num">{loading ? '—' : records.length}</div>
          <div className="stat-label">投递记录</div>
        </div>
        <div className="stat-box">
          <div className="stat-num">{loading ? '—' : companies}</div>
          <div className="stat-label">公司数量</div>
        </div>
        <div className="stat-box">
          <div className="stat-num">{loading ? '—' : avgScore}</div>
          <div className="stat-label">平均匹配分</div>
        </div>
      </div>

      {!hasResume && !loading && (
        <div className="card" style={{ borderColor: 'var(--clay-lt)', background: 'rgba(212,180,140,0.08)' }}>
          <div className="card-title"><span className="dot" style={{ background: 'var(--clay)' }}/> 先上传一份主简历</div>
          <p style={{ fontSize: 13, color: 'var(--ink-lt)', lineHeight: 1.8, marginBottom: 18 }}>
            上传你的主简历后，每次分析时会自动复用，不必重复上传。
          </p>
          <div className="btn-row" style={{ marginTop: 0 }}>
            <Link href="/resume"><button className="btn btn-primary">☰ 上传主简历</button></Link>
          </div>
        </div>
      )}

      <div className="card">
        <div className="card-title"><span className="dot"/> 从这里开始</div>
        <p style={{ fontSize: 13, color: 'var(--ink-lt)', lineHeight: 1.85, marginBottom: 22 }}>
          上传简历与岗位描述，AI 会给出 <strong>匹配度评分</strong> 与 <strong>逐条修改建议</strong>。<br/>
          面试结束后，记录问答内容，下次投递时 AI 会基于你的历史经验给出个性化备考建议。
        </p>
        <div className="btn-row" style={{ marginTop: 0 }}>
          <Link href="/analyze"><button className="btn btn-primary">✦ 简历匹配分析</button></Link>
          <Link href="/log"><button className="btn btn-ghost">+ 记录面试</button></Link>
          <Link href="/prep"><button className="btn btn-ghost">⊹ 面试准备</button></Link>
        </div>
      </div>

      {records.length > 0 && (
        <div className="card">
          <div className="card-title"><span className="dot" style={{ background: 'var(--sage)' }}/> 最近投递</div>
          {records.slice(0, 4).map((r, i) => (
            <div key={r.id} style={{
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              padding: '13px 0',
              borderBottom: i < Math.min(records.length, 4) - 1 ? '1px solid var(--border)' : 'none'
            }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 15, fontFamily: "'Cormorant Garamond', serif", color: 'var(--ink)', fontWeight: 500 }}>{r.company}</div>
                <div style={{ fontSize: 12, color: 'var(--ink-lt)', marginTop: 2 }}>{r.role || '—'}{r.round ? ` · ${r.round}` : ''}</div>
              </div>
              {r.match_score && (
                <div style={{ fontSize: 12, padding: '3px 10px', borderRadius: 20,
                  background: 'rgba(201,169,154,0.18)', color: 'var(--rose-dark)', marginRight: 14,
                  fontWeight: 500 }}>
                  {r.match_score}/10
                </div>
              )}
              <div style={{ fontSize: 11, color: 'var(--mist)' }}>
                {new Date(r.created_at).toLocaleDateString('zh-CN')}
              </div>
            </div>
          ))}
          {records.length > 4 && (
            <Link href="/history" style={{ textDecoration: 'none' }}>
              <div style={{ fontSize: 12, color: 'var(--rose-dark)', marginTop: 14, cursor: 'pointer' }}>
                查看全部 {records.length} 条记录 →
              </div>
            </Link>
          )}
        </div>
      )}
    </Layout>
  )
}
