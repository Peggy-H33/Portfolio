import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import Layout from '../components/Layout'

function LoadingDots() {
  return <span className="loading-dots"><span/><span/><span/></span>
}

export default function AnalyzePage() {
  const [resumeText,   setResumeText]   = useState('')
  const [resumeSource, setResumeSource] = useState('') // 'master' | 'upload' | 'paste'
  const [resumeFile,   setResumeFile]   = useState(null)
  const [jdText,       setJdText]       = useState('')
  const [jdFile,       setJdFile]       = useState(null)
  const [company,      setCompany]      = useState('')
  const [role,         setRole]         = useState('')
  const [result,       setResult]       = useState('')
  const [score,        setScore]        = useState(null)
  const [loading,      setLoading]      = useState(false)
  const [parsingRes,   setParsingRes]   = useState(false)
  const [parsingJd,    setParsingJd]    = useState(false)
  const [toast,        setToast]        = useState('')
  const [hasMaster,    setHasMaster]    = useState(false)
  const resumeRef = useRef()
  const jdRef     = useRef()

  function showToast(m) { setToast(m); setTimeout(() => setToast(''), 2800) }

  // Pre-load master resume
  useEffect(() => {
    fetch('/api/resume').then(r => r.json()).then(d => {
      if (d.data?.content) {
        setResumeText(d.data.content)
        setResumeSource('master')
        setHasMaster(true)
      }
    })
  }, [])

  async function parseUpload(file, setFn, setParsingFn, isResume) {
    setParsingFn(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const resp = await fetch('/api/parse-file', { method: 'POST', body: fd })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      setFn(data.text)
      if (isResume) { setResumeFile(file); setResumeSource('upload') }
      else { setJdFile(file); setJdText(data.text) }
      showToast(`✓ 已解析 ${data.fileName}`)
    } catch (e) {
      showToast('解析失败: ' + e.message)
    }
    setParsingFn(false)
  }

  async function analyze() {
    if (!resumeText.trim() || !jdText.trim()) {
      showToast('请提供简历和岗位描述')
      return
    }
    setLoading(true); setResult(''); setScore(null)
    try {
      const resp = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText, jdText })
      })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      setResult(data.result)
      setScore(data.score)

      // Auto-save if company is provided
      if (company) {
        await fetch('/api/applications/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            company, role,
            resume_text: resumeText,
            jd_text: jdText,
            analyze_result: data.result,
            match_score: data.score
          })
        })
        showToast('✓ 分析结果已保存到历史')
      }
    } catch (e) {
      showToast('分析失败: ' + e.message)
    }
    setLoading(false)
  }

  return (
    <Layout>
      <div className="page-title">简历匹配分析</div>
      <p className="page-sub">AI 给出匹配度评分，并提供逐条修改建议</p>

      <div className="card">
        <div className="card-title"><span className="dot"/> 投递信息（可选）</div>
        <div className="form-grid-2">
          <div className="form-group">
            <label className="form-label">公司名称</label>
            <input type="text" value={company} onChange={e => setCompany(e.target.value)} placeholder="例：字节跳动"/>
          </div>
          <div className="form-group">
            <label className="form-label">岗位</label>
            <input type="text" value={role} onChange={e => setRole(e.target.value)} placeholder="例：产品经理实习生"/>
          </div>
        </div>
        <div style={{ fontSize: 11.5, color: 'var(--ink-lt)', marginTop: -4 }}>
          💡 填写公司名称后，分析结果会自动存入历史记录
        </div>
      </div>

      <div className="card">
        <div className="card-title"><span className="dot" style={{ background: 'var(--sage)' }}/> 我的简历</div>

        {hasMaster && resumeSource === 'master' && (
          <div style={{
            padding: '10px 14px', background: 'rgba(143,168,140,0.1)',
            borderRadius: 7, fontSize: 12.5, color: 'var(--sage-dark)',
            border: '1px solid rgba(143,168,140,0.25)', marginBottom: 14,
            display: 'flex', justifyContent: 'space-between', alignItems: 'center'
          }}>
            <span>✓ 正在使用你的主简历（<Link href="/resume" style={{ color: 'var(--sage-dark)', textDecoration: 'underline' }}>编辑</Link>）</span>
            <button className="btn btn-danger" style={{ fontSize: 11, padding: '4px 10px' }}
              onClick={() => { setResumeText(''); setResumeSource('paste') }}>
              不使用
            </button>
          </div>
        )}

        {resumeSource !== 'master' && (
          <>
            <div className={`upload-zone ${resumeFile ? 'filled' : ''}`} onClick={() => resumeRef.current.click()}
              style={{ marginBottom: 14 }}>
              <input ref={resumeRef} type="file" accept=".pdf,.docx,.txt" style={{ display: 'none' }}
                onChange={e => e.target.files[0] && parseUpload(e.target.files[0], setResumeText, setParsingRes, true)}/>
              <div className="upload-icon">{parsingRes ? '⟳' : resumeFile ? '📄' : '📎'}</div>
              <div className="upload-label">{parsingRes ? '解析中…' : resumeFile ? resumeFile.name : '上传简历'}</div>
              <div className="upload-hint">PDF / DOCX / TXT</div>
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label className="form-label">或直接粘贴简历内容</label>
              <textarea rows={6} value={resumeText} onChange={e => { setResumeText(e.target.value); setResumeSource('paste') }}
                placeholder="在此粘贴简历内容…"/>
            </div>
          </>
        )}
      </div>

      <div className="card">
        <div className="card-title"><span className="dot" style={{ background: 'var(--slate)' }}/> 岗位描述 JD</div>

        <div className={`upload-zone ${jdFile ? 'filled' : ''}`} onClick={() => jdRef.current.click()}
          style={{ marginBottom: 14 }}>
          <input ref={jdRef} type="file" accept=".pdf,.docx,.txt" style={{ display: 'none' }}
            onChange={e => e.target.files[0] && parseUpload(e.target.files[0], setJdText, setParsingJd, false)}/>
          <div className="upload-icon">{parsingJd ? '⟳' : jdFile ? '📋' : '📋'}</div>
          <div className="upload-label">{parsingJd ? '解析中…' : jdFile ? jdFile.name : '上传岗位描述'}</div>
          <div className="upload-hint">PDF / DOCX / TXT</div>
        </div>

        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label">或直接粘贴岗位描述</label>
          <textarea rows={6} value={jdText} onChange={e => { setJdText(e.target.value); setJdFile(null) }}
            placeholder="在此粘贴完整的岗位描述…"/>
        </div>

        <div className="btn-row">
          <button className="btn btn-primary" disabled={loading || !resumeText.trim() || !jdText.trim()} onClick={analyze}>
            {loading ? <LoadingDots/> : '✦ 开始分析'}
          </button>
        </div>
      </div>

      {result && (
        <div className="ai-result">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 12, marginBottom: 14 }}>
            <div className="ai-badge" style={{ marginBottom: 0 }}>AI 简历教练</div>
            {score !== null && (
              <div style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: 24, fontWeight: 500,
                color: score >= 7 ? 'var(--sage-dark)' : score >= 5 ? 'var(--clay)' : 'var(--rose-dark)',
                lineHeight: 1
              }}>
                {score}<span style={{ fontSize: 14, color: 'var(--mist)' }}> / 10</span>
              </div>
            )}
          </div>
          <div>{result}</div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </Layout>
  )
}
