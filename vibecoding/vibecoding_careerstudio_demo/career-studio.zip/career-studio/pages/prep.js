import { useEffect, useRef, useState } from 'react'
import Layout from '../components/Layout'

function LoadingDots() {
  return <span className="loading-dots"><span/><span/><span/></span>
}

export default function PrepPage() {
  const [jdText,    setJdText]    = useState('')
  const [jdFile,    setJdFile]    = useState(null)
  const [company,   setCompany]   = useState('')
  const [role,      setRole]      = useState('')
  const [parsing,   setParsing]   = useState(false)
  const [result,    setResult]    = useState('')
  const [loading,   setLoading]   = useState(false)
  const [histCount, setHistCount] = useState(0)
  const [toast,     setToast]     = useState('')
  const jdRef = useRef()

  function showToast(m) { setToast(m); setTimeout(() => setToast(''), 2800) }

  useEffect(() => {
    fetch('/api/applications/list')
      .then(r => r.json())
      .then(d => setHistCount((d.data || []).filter(r => r.qa_text).length))
  }, [])

  async function parseJd(file) {
    setParsing(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const resp = await fetch('/api/parse-file', { method: 'POST', body: fd })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      setJdText(data.text)
      setJdFile(file)
      showToast(`✓ 已解析 ${data.fileName}`)
    } catch (e) {
      showToast('解析失败: ' + e.message)
    }
    setParsing(false)
  }

  async function getPrep() {
    if (!jdText.trim()) { showToast('请提供岗位描述'); return }
    setLoading(true); setResult('')
    try {
      const resp = await fetch('/api/prep', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ jdText })
      })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      setResult(data.result)

      if (company) {
        await fetch('/api/applications/save', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ company, role, jd_text: jdText, prep_result: data.result })
        })
        showToast('✓ 备考计划已保存')
      }
    } catch (e) {
      showToast('生成失败: ' + e.message)
    }
    setLoading(false)
  }

  return (
    <Layout>
      <div className="page-title">面试准备</div>
      <p className="page-sub">结合你的历史面试经验，AI 生成针对性备考计划</p>

      <div className="card">
        <div className="card-title"><span className="dot" style={{ background: 'var(--sage)' }}/> 目标岗位</div>

        <div className="form-grid-2">
          <div className="form-group">
            <label className="form-label">公司（可选，用于保存）</label>
            <input type="text" value={company} onChange={e => setCompany(e.target.value)} placeholder="例：腾讯"/>
          </div>
          <div className="form-group">
            <label className="form-label">岗位</label>
            <input type="text" value={role} onChange={e => setRole(e.target.value)} placeholder="例：PCG 产品实习"/>
          </div>
        </div>

        <div className={`upload-zone ${jdFile ? 'filled' : ''}`} onClick={() => jdRef.current.click()}
          style={{ marginBottom: 14 }}>
          <input ref={jdRef} type="file" accept=".pdf,.docx,.txt" style={{ display: 'none' }}
            onChange={e => e.target.files[0] && parseJd(e.target.files[0])}/>
          <div className="upload-icon">{parsing ? '⟳' : jdFile ? '📋' : '📋'}</div>
          <div className="upload-label">{parsing ? '解析中…' : jdFile ? jdFile.name : '上传岗位描述'}</div>
          <div className="upload-hint">PDF / DOCX / TXT</div>
        </div>

        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label">或粘贴岗位描述</label>
          <textarea rows={6} value={jdText} onChange={e => { setJdText(e.target.value); setJdFile(null) }}
            placeholder="粘贴你即将投递的岗位描述…"/>
        </div>

        <div style={{ marginTop: 14 }}>
          {histCount > 0 ? (
            <div style={{
              padding: '10px 14px', background: 'rgba(143,168,140,0.1)',
              borderRadius: 7, fontSize: 12.5, color: 'var(--sage-dark)',
              border: '1px solid rgba(143,168,140,0.25)'
            }}>
              ✓ 将结合你的 <strong>{histCount}</strong> 条历史面试记录生成个性化建议
            </div>
          ) : (
            <div style={{ fontSize: 12, color: 'var(--mist)' }}>
              暂无历史面试记录 — 先在「记录面试」添加后，准备建议会更个性化
            </div>
          )}
        </div>

        <div className="btn-row">
          <button className="btn btn-sage" disabled={loading || !jdText.trim()} onClick={getPrep}>
            {loading ? <LoadingDots/> : '⊹ 生成备考计划'}
          </button>
        </div>
      </div>

      {result && (
        <div className="ai-result">
          <div className="ai-badge">AI 面试教练</div>
          <div>{result}</div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </Layout>
  )
}
