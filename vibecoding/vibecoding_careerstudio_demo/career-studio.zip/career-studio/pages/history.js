import { useEffect, useState } from 'react'
import Layout from '../components/Layout'

export default function HistoryPage() {
  const [records,  setRecords]  = useState([])
  const [loading,  setLoading]  = useState(true)
  const [selected, setSelected] = useState(null)
  const [filter,   setFilter]   = useState('all')
  const [toast,    setToast]    = useState('')

  function showToast(m) { setToast(m); setTimeout(() => setToast(''), 2500) }

  useEffect(() => { load() }, [])

  function load() {
    fetch('/api/applications/list').then(r => r.json()).then(d => {
      setRecords(d.data || [])
      setLoading(false)
    })
  }

  async function del(id, e) {
    e.stopPropagation()
    if (!confirm('确认删除这条记录？')) return
    await fetch(`/api/applications/delete?id=${id}`, { method: 'DELETE' })
    setRecords(prev => prev.filter(r => r.id !== id))
    if (selected === id) setSelected(null)
    showToast('已删除')
  }

  const filtered = records.filter(r => {
    if (filter === 'all')     return true
    if (filter === 'qa')      return r.qa_text
    if (filter === 'analyze') return r.analyze_result
    if (filter === 'prep')    return r.prep_result
    return true
  })

  return (
    <Layout recordCount={records.length}>
      <div className="page-title">历史记录</div>
      <p className="page-sub">所有投递、面试笔记与 AI 分析结果</p>

      <div style={{ display: 'flex', gap: 8, marginBottom: 20, flexWrap: 'wrap' }}>
        {[
          ['all',     '全部',     records.length],
          ['analyze', 'AI分析',   records.filter(r => r.analyze_result).length],
          ['qa',      '面试笔记', records.filter(r => r.qa_text).length],
          ['prep',    '备考计划', records.filter(r => r.prep_result).length],
        ].map(([k, label, count]) => (
          <button key={k} onClick={() => setFilter(k)}
            className={`btn ${filter === k ? 'btn-primary' : 'btn-ghost'}`}
            style={{ fontSize: 12, padding: '7px 16px' }}>
            {label} · {count}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="empty-state">载入中…</div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">暂无记录</div>
      ) : (
        <div className="interview-list">
          {filtered.map(r => (
            <div key={r.id}>
              <div className={`interview-card ${selected === r.id ? 'selected' : ''}`}
                onClick={() => setSelected(selected === r.id ? null : r.id)}
                style={{ borderRadius: selected === r.id ? '10px 10px 0 0' : '10px' }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <div className="ic-company">{r.company}</div>
                    {r.match_score && (
                      <span style={{
                        fontSize: 11, padding: '2px 9px', borderRadius: 20,
                        background: r.match_score >= 7 ? 'rgba(143,168,140,0.18)' : 'rgba(201,169,154,0.18)',
                        color: r.match_score >= 7 ? 'var(--sage-dark)' : 'var(--rose-dark)',
                        fontWeight: 500
                      }}>
                        {r.match_score}/10
                      </span>
                    )}
                  </div>
                  <div className="ic-role">{r.role || '—'}{r.round ? ` · ${r.round}` : ''}</div>
                  <div className="ic-tags">
                    {r.qa_text        && <span className="tag tag-sage">面试笔记</span>}
                    {r.analyze_result && <span className="tag tag-rose">AI分析</span>}
                    {r.prep_result    && <span className="tag tag-slate">备考计划</span>}
                    {r.jd_text        && <span className="tag tag-slate">JD</span>}
                  </div>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 10, flexShrink: 0 }}>
                  <div className="ic-date">{new Date(r.created_at).toLocaleDateString('zh-CN')}</div>
                  <button className="btn btn-danger" onClick={e => del(r.id, e)}>删除</button>
                </div>
              </div>

              {selected === r.id && (
                <div className="detail-panel">
                  {r.qa_text && (
                    <>
                      <div className="detail-section-title">📝 面试问答记录</div>
                      <div className="detail-text" style={{ marginBottom: 18 }}>{r.qa_text}</div>
                    </>
                  )}
                  {r.analyze_result && (
                    <>
                      {r.qa_text && <hr className="divider"/>}
                      <div className="detail-section-title">✦ AI 简历分析</div>
                      <div className="detail-text" style={{ marginBottom: 18 }}>{r.analyze_result}</div>
                    </>
                  )}
                  {r.prep_result && (
                    <>
                      {(r.qa_text || r.analyze_result) && <hr className="divider"/>}
                      <div className="detail-section-title">⊹ AI 备考计划</div>
                      <div className="detail-text" style={{ marginBottom: 18 }}>{r.prep_result}</div>
                    </>
                  )}
                  {r.jd_text && (
                    <>
                      {(r.qa_text || r.analyze_result || r.prep_result) && <hr className="divider"/>}
                      <div className="detail-section-title">📋 岗位描述</div>
                      <div className="detail-text" style={{ maxHeight: 200, overflowY: 'auto' }}>{r.jd_text}</div>
                    </>
                  )}
                  {!r.qa_text && !r.analyze_result && !r.prep_result && !r.jd_text && (
                    <div style={{ fontSize: 13, color: 'var(--mist)', fontStyle: 'italic' }}>暂无详细内容</div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </Layout>
  )
}
