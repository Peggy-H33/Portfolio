import { useEffect, useRef, useState } from 'react'
import Layout from '../components/Layout'

export default function ResumePage() {
  const [content,  setContent]  = useState('')
  const [fileName, setFileName] = useState('')
  const [loading,  setLoading]  = useState(true)
  const [saving,   setSaving]   = useState(false)
  const [parsing,  setParsing]  = useState(false)
  const [toast,    setToast]    = useState('')
  const fileRef = useRef()

  function showToast(msg) { setToast(msg); setTimeout(() => setToast(''), 2800) }

  useEffect(() => {
    fetch('/api/resume').then(r => r.json()).then(d => {
      if (d.data) { setContent(d.data.content || ''); setFileName(d.data.file_name || '') }
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  async function handleFile(e) {
    const file = e.target.files[0]
    if (!file) return
    setParsing(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const resp = await fetch('/api/parse-file', { method: 'POST', body: fd })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      setContent(data.text)
      setFileName(data.fileName)
      showToast(`✓ 已解析 ${data.fileName}`)
    } catch (e) {
      showToast('解析失败: ' + e.message)
    }
    setParsing(false)
  }

  async function save() {
    if (!content.trim()) { showToast('简历内容不能为空'); return }
    setSaving(true)
    try {
      const resp = await fetch('/api/resume', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, file_name: fileName })
      })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      showToast('✓ 主简历已保存')
    } catch (e) {
      showToast('保存失败: ' + e.message)
    }
    setSaving(false)
  }

  return (
    <Layout>
      <div className="page-title">我的简历</div>
      <p className="page-sub">上传或粘贴你的主简历，之后分析和面试准备会自动复用</p>

      <div className="card">
        <div className="card-title"><span className="dot"/> 上传简历文件</div>

        <div className={`upload-zone ${fileName ? 'filled' : ''}`} onClick={() => fileRef.current.click()}
          style={{ marginBottom: 20 }}>
          <input ref={fileRef} type="file" accept=".pdf,.docx,.txt,.md" style={{ display: 'none' }} onChange={handleFile}/>
          <div className="upload-icon">{parsing ? '⟳' : fileName ? '📄' : '📎'}</div>
          <div className="upload-label">{parsing ? '解析中…' : fileName ? fileName : '点击上传简历'}</div>
          <div className="upload-hint">支持 PDF / DOCX / TXT（最大 10MB）</div>
        </div>

        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label">简历内容（可手动编辑）</label>
          <textarea rows={18} value={content} onChange={e => setContent(e.target.value)}
            placeholder={loading ? '载入中…' : '在此粘贴或编辑简历内容…'} disabled={loading}/>
        </div>

        <div className="btn-row">
          <button className="btn btn-primary" disabled={saving || loading || !content.trim()} onClick={save}>
            {saving ? '保存中…' : '保存主简历'}
          </button>
          <span style={{ fontSize: 12, color: 'var(--ink-lt)' }}>
            {content.length > 0 && `${content.length} 字符`}
          </span>
        </div>
      </div>

      {toast && <div className="toast">{toast}</div>}
    </Layout>
  )
}
