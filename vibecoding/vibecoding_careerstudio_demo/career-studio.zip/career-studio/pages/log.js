import { useState } from 'react'
import Layout from '../components/Layout'

export default function LogPage() {
  const [company, setCompany] = useState('')
  const [role,    setRole]    = useState('')
  const [round,   setRound]   = useState('HR初筛')
  const [qaText,  setQaText]  = useState('')
  const [saving,  setSaving]  = useState(false)
  const [toast,   setToast]   = useState('')

  function showToast(m) { setToast(m); setTimeout(() => setToast(''), 2800) }

  async function save() {
    if (!company || !qaText) { showToast('请填写公司名称和面试内容'); return }
    setSaving(true)
    try {
      const resp = await fetch('/api/applications/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company, role, round, qa_text: qaText })
      })
      const data = await resp.json()
      if (data.error) throw new Error(data.error)
      showToast('✓ 面试记录已保存')
      setCompany(''); setRole(''); setQaText('')
    } catch (e) {
      showToast('保存失败: ' + e.message)
    }
    setSaving(false)
  }

  return (
    <Layout>
      <div className="page-title">记录面试</div>
      <p className="page-sub">记录每次面试的问答与反馈，积累个人经验库</p>

      <div className="card">
        <div className="card-title"><span className="dot" style={{ background: 'var(--slate)' }}/> 面试信息</div>
        <div className="form-grid-3">
          <div className="form-group">
            <label className="form-label">公司名称 *</label>
            <input type="text" value={company} onChange={e => setCompany(e.target.value)} placeholder="例：美团"/>
          </div>
          <div className="form-group">
            <label className="form-label">岗位</label>
            <input type="text" value={role} onChange={e => setRole(e.target.value)} placeholder="例：产品实习生"/>
          </div>
          <div className="form-group">
            <label className="form-label">面试轮次</label>
            <select value={round} onChange={e => setRound(e.target.value)}>
              {['HR初筛','产品能力面','技术面','案例分析','交叉面','终面','其他'].map(o => <option key={o}>{o}</option>)}
            </select>
          </div>
        </div>

        <div className="form-group" style={{ marginBottom: 0 }}>
          <label className="form-label">面试问答内容 *</label>
          <textarea rows={11} value={qaText} onChange={e => setQaText(e.target.value)}
            placeholder={`记录面试中的问题、你的回答和面试官反馈，例如：\n\nQ：如何改进微信朋友圈的创作体验？\nA：我会从创作者侧入手，目前发布流程步骤过多……\n反馈：面试官认可数据思路，但觉得对用户侧分析不够\n\nQ：说一个你用数据驱动决策的案例。\nA：在上一段实习中，我通过分析留存漏斗发现……`}/>
        </div>

        <div className="btn-row">
          <button className="btn btn-primary" disabled={saving || !company || !qaText} onClick={save}>
            {saving ? '保存中…' : '+ 保存面试记录'}
          </button>
        </div>
      </div>

      <div style={{ fontSize: 12, color: 'var(--ink-lt)', paddingLeft: 2, lineHeight: 1.7 }}>
        💡 建议在面试结束当天记录，细节最为完整<br/>
        💡 记录越丰富，AI 生成的面试准备建议就越精准
      </div>

      {toast && <div className="toast">{toast}</div>}
    </Layout>
  )
}
