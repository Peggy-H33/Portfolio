import formidable from 'formidable'
import fs from 'fs/promises'
import { requireUser } from '../../lib/auth'

export const config = { api: { bodyParser: false } }

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const auth = await requireUser(req, res)
  if (!auth) return

  try {
    const form = formidable({ maxFileSize: 10 * 1024 * 1024 })
    const [_, files] = await form.parse(req)
    const file = files.file?.[0]
    if (!file) return res.status(400).json({ error: '未找到文件' })

    const ext = file.originalFilename?.toLowerCase().split('.').pop()
    const buffer = await fs.readFile(file.filepath)
    let text = ''

    if (ext === 'pdf') {
      const pdfParse = (await import('pdf-parse')).default
      const data = await pdfParse(buffer)
      text = data.text
    } else if (ext === 'docx') {
      const mammoth = await import('mammoth')
      const { value } = await mammoth.extractRawText({ buffer })
      text = value
    } else if (ext === 'txt' || ext === 'md') {
      text = buffer.toString('utf-8')
    } else {
      return res.status(400).json({ error: `不支持的文件格式: .${ext}（仅支持 PDF / DOCX / TXT）` })
    }

    // Cleanup: normalize whitespace
    text = text.replace(/\n{3,}/g, '\n\n').trim()

    await fs.unlink(file.filepath).catch(() => {})

    res.status(200).json({ text, fileName: file.originalFilename })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
}
