import { requireUser } from '../../lib/auth'

export default async function handler(req, res) {
  const auth = await requireUser(req, res)
  if (!auth) return
  const { supabase, user } = auth

  if (req.method === 'GET') {
    const { data, error } = await supabase
      .from('resumes')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle()

    if (error) return res.status(500).json({ error: error.message })
    return res.status(200).json({ data })
  }

  if (req.method === 'POST') {
    const { content, file_name, title } = req.body
    if (!content) return res.status(400).json({ error: '简历内容不能为空' })

    // Upsert: one "current" resume per user
    const { data: existing } = await supabase
      .from('resumes')
      .select('id')
      .eq('user_id', user.id)
      .maybeSingle()

    if (existing) {
      const { data, error } = await supabase
        .from('resumes')
        .update({ content, file_name, title: title || 'My Resume' })
        .eq('id', existing.id)
        .select()
        .single()
      if (error) return res.status(500).json({ error: error.message })
      return res.status(200).json({ data })
    } else {
      const { data, error } = await supabase
        .from('resumes')
        .insert([{ user_id: user.id, content, file_name, title: title || 'My Resume' }])
        .select()
        .single()
      if (error) return res.status(500).json({ error: error.message })
      return res.status(200).json({ data })
    }
  }

  res.status(405).end()
}
