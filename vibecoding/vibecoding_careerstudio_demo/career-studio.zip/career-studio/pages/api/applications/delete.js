import { requireUser } from '../../../lib/auth'

export default async function handler(req, res) {
  if (req.method !== 'DELETE') return res.status(405).end()
  const auth = await requireUser(req, res)
  if (!auth) return
  const { supabase, user } = auth

  const { id } = req.query
  if (!id) return res.status(400).json({ error: 'Missing id' })

  const { error } = await supabase
    .from('applications')
    .delete()
    .eq('id', id)
    .eq('user_id', user.id)

  if (error) return res.status(500).json({ error: error.message })
  res.status(200).json({ success: true })
}
