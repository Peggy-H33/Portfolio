import { requireUser } from '../../../lib/auth'

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const auth = await requireUser(req, res)
  if (!auth) return
  const { supabase, user } = auth

  const { company, role, round, resume_text, jd_text, qa_text, analyze_result, prep_result, match_score } = req.body
  if (!company) return res.status(400).json({ error: '公司名称不能为空' })

  const { data, error } = await supabase
    .from('applications')
    .insert([{
      user_id: user.id,
      company, role, round,
      resume_text: resume_text || null,
      jd_text: jd_text || null,
      qa_text: qa_text || null,
      analyze_result: analyze_result || null,
      prep_result: prep_result || null,
      match_score: match_score || null
    }])
    .select()
    .single()

  if (error) return res.status(500).json({ error: error.message })
  res.status(200).json({ data })
}
