import Anthropic from '@anthropic-ai/sdk'
import { requireUser } from '../../lib/auth'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const auth = await requireUser(req, res)
  if (!auth) return
  const { supabase, user } = auth

  const { jdText } = req.body
  if (!jdText) return res.status(400).json({ error: '请提供岗位描述' })

  // Pull user's past interviews from DB (only ones with actual QA content)
  const { data: past } = await supabase
    .from('applications')
    .select('company, role, round, qa_text')
    .eq('user_id', user.id)
    .not('qa_text', 'is', null)
    .neq('qa_text', '')
    .order('created_at', { ascending: false })
    .limit(20)

  const historyBlock = past?.length
    ? past.map(r => `【${r.company} · ${r.role || ''} · ${r.round || ''}】\n${r.qa_text}`).join('\n\n---\n\n')
    : '(暂无历史面试记录)'

  try {
    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1800,
      system: `You are a seasoned PM interview coach specializing in Chinese internet companies.
Use the candidate's past interview experiences to give highly personalized, targeted advice.
Respond in Chinese.

Format your response EXACTLY with these sections:

🔍 岗位解析
(2-3 sentences on what this company / role specifically values in a PM)

💡 预测高频题（5 道）
1. **[Question]**
   答题思路：(brief framework)
2. **[Question]**
   答题思路：...
(continue for 5)

🎯 你的制胜角度
(based on past experience, list 3 specific stories/cases to emphasize in this interview)

⚠️ 注意弱项
(identify 2-3 gaps based on past interviews and how to prepare)

📝 实战练习题
(one product case question to practice right now, with a hint framework)`,
      messages: [
        { role: 'user', content: `【目标岗位 JD】\n${jdText.slice(0, 2500)}\n\n【我的历史面试经验】\n${historyBlock.slice(0, 4000)}` }
      ]
    })

    const result = message.content.map(b => b.text || '').join('\n')
    res.status(200).json({ result })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
}
