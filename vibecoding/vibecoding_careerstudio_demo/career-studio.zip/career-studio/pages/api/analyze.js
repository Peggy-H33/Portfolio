import Anthropic from '@anthropic-ai/sdk'
import { requireUser } from '../../lib/auth'

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end()
  const auth = await requireUser(req, res)
  if (!auth) return

  const { resumeText, jdText } = req.body
  if (!resumeText || !jdText) return res.status(400).json({ error: '请提供简历和岗位描述' })

  try {
    const message = await client.messages.create({
      model: 'claude-opus-4-5',
      max_tokens: 1800,
      system: `You are an expert PM career coach helping students land PM internships at top Chinese internet companies (字节跳动, 阿里巴巴, 美团, 腾讯, 小红书, etc.).
Be warm, specific, and brutally actionable. Respond in Chinese (the user is Chinese).

Format your response EXACTLY with these sections, using the exact section headers below:

📊 匹配度评分：X/10
(one-line summary of overall fit)

🎯 核心优势
- (3 specific bullets on what already aligns well with the JD)

⚡ 优先修改建议
1. **[Section name, e.g. 项目经历]**：(concrete before/after rewrite example)
2. **[Section]**：(concrete advice)
3. **[Section]**：(concrete advice)

📌 建议补充关键词
(comma-separated list of keywords from JD missing in resume)

✨ 一句话定位
(rewrite the resume summary for this specific role in 1-2 sentences)`,
      messages: [
        { role: 'user', content: `【我的简历】\n${resumeText.slice(0, 4000)}\n\n【目标岗位 JD】\n${jdText.slice(0, 2500)}` }
      ]
    })

    const result = message.content.map(b => b.text || '').join('\n')
    const scoreMatch = result.match(/匹配度评分[：:]\s*(\d+)/)
    const score = scoreMatch ? parseInt(scoreMatch[1], 10) : null

    res.status(200).json({ result, score })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: err.message })
  }
}
