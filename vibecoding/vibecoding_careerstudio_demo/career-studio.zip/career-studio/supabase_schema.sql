-- ============================================================
-- Career Studio — Supabase Schema (v2 with auth)
-- Run this in Supabase SQL Editor
-- ============================================================

-- Applications table
create table if not exists applications (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid references auth.users(id) on delete cascade not null,
  created_at     timestamptz default now(),
  updated_at     timestamptz default now(),
  company        text not null,
  role           text,
  round          text,
  resume_text    text,
  jd_text        text,
  qa_text        text,
  analyze_result text,
  prep_result    text,
  match_score    int
);

-- Master resume (one per user, the "current" version)
create table if not exists resumes (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references auth.users(id) on delete cascade not null,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now(),
  title       text default 'My Resume',
  content     text not null,
  file_name   text
);

-- Indexes
create index if not exists idx_applications_user on applications (user_id, created_at desc);
create index if not exists idx_resumes_user on resumes (user_id, created_at desc);

-- Row Level Security
alter table applications enable row level security;
alter table resumes enable row level security;

-- Policies: users can only access their own data
drop policy if exists "own_applications" on applications;
create policy "own_applications" on applications
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

drop policy if exists "own_resumes" on resumes;
create policy "own_resumes" on resumes
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Auto-update updated_at
create or replace function update_updated_at() returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

drop trigger if exists trg_app_updated on applications;
create trigger trg_app_updated before update on applications
  for each row execute function update_updated_at();

drop trigger if exists trg_res_updated on resumes;
create trigger trg_res_updated before update on resumes
  for each row execute function update_updated_at();
