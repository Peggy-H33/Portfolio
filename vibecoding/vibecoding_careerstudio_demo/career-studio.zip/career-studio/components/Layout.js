import { useRouter } from 'next/router'
import { useEffect } from 'react'
import Link from 'next/link'
import { useSupabaseClient, useUser, useSessionContext } from '@supabase/auth-helpers-react'

const navItems = [
  { href: '/',        icon: '⌂', label: '仪表盘' },
  { href: '/resume',  icon: '☰', label: '我的简历' },
  { href: '/analyze', icon: '◈', label: '简历匹配分析' },
  { href: '/log',     icon: '✎', label: '记录面试' },
  { href: '/prep',    icon: '⊹', label: '面试准备' },
  { href: '/history', icon: '◷', label: '历史记录' },
]

export default function Layout({ children, recordCount = 0, requireAuth = true }) {
  const router   = useRouter()
  const user     = useUser()
  const supabase = useSupabaseClient()
  const { isLoading } = useSessionContext()

  useEffect(() => {
    if (!isLoading && !user && requireAuth) router.push('/login')
  }, [user, isLoading, requireAuth, router])

  async function signOut() {
    await supabase.auth.signOut()
    router.push('/login')
  }

  if (isLoading) {
    return <div style={{ padding: 60, textAlign: 'center', color: 'var(--mist)', fontStyle: 'italic', fontFamily: "'Cormorant Garamond', serif" }}>载入中…</div>
  }

  if (!user && requireAuth) return null

  const initial = user?.email?.[0]?.toUpperCase() || '?'

  return (
    <div className="layout">
      <aside className="sidebar">
        <div className="logo">
          <div className="logo-title">Career Studio</div>
          <div className="logo-sub">PM 实习求职助手</div>
        </div>

        <div className="nav-section">菜单</div>
        {navItems.map(n => (
          <Link key={n.href} href={n.href} style={{ textDecoration: 'none' }}>
            <div className={`nav-item ${router.pathname === n.href ? 'active' : ''}`}>
              <span className="nav-icon">{n.icon}</span>
              {n.label}
            </div>
          </Link>
        ))}

        <div className="nav-footer">
          {user && (
            <div className="user-chip">
              <div className="avatar">{initial}</div>
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: 11.5, color: 'var(--ink)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {user.email}
                </div>
                <div onClick={signOut} style={{ fontSize: 10.5, color: 'var(--ink-lt)', cursor: 'pointer', marginTop: 2 }}>
                  退出登录 →
                </div>
              </div>
            </div>
          )}
          <div style={{ fontSize: 10.5, color: 'var(--mist)', marginTop: 10 }}>
            {recordCount} 条记录
          </div>
        </div>
      </aside>

      <main className="main-content fade-in">
        {children}
      </main>

      <style jsx>{`
        .user-chip {
          display: flex; align-items: center; gap: 9px;
          padding: 10px 12px;
          background: var(--white);
          border: 1px solid var(--border);
          border-radius: 9px;
        }
        .avatar {
          width: 30px; height: 30px; border-radius: 50%;
          background: var(--rose-dark); color: #fff;
          display: flex; align-items: center; justify-content: center;
          font-family: 'Cormorant Garamond', serif; font-weight: 500;
          font-size: 14px; flex-shrink: 0;
        }
      `}</style>
    </div>
  )
}
